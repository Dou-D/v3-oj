import{c as e,u as a,o as r,R as o}from"./index-CgEbMgE_.js";const _={__name:"main",setup(t){return(c,s)=>(r(),e(a(o)))}};export{_ as default};
