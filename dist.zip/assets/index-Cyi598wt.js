import{c as e,u as r,o as a,R as o}from"./index-CgEbMgE_.js";const _={__name:"index",setup(t){return(c,s)=>(a(),e(r(o)))}};export{_ as default};
