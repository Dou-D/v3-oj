import{c as e,u as r,o as s,R as a}from"./index-CgEbMgE_.js";const _={__name:"users",setup(o){return(t,c)=>(s(),e(r(a)))}};export{_ as default};
