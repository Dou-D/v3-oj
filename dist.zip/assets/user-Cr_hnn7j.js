import{x as e}from"./index-CgEbMgE_.js";const o=e("user",()=>({menu:[{id:1,title:"个人中心",path:"problem"},{id:2,title:"退出",path:"problem"}]}));export{o as u};
